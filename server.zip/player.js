var Player = function(id,x,y,rotate){
    this.x=x;
    this.y=y;
    this.id=id;
    this.rotate=rotate;
    this.img=null;
    this.speed=0;
    this.max_speed=5;
    this.hp=100;
    this.rotating=false;
    this.rotating_direction=true;
    this.bullets=[[0,0,false,0],[0,0,false,0],[0,0,false,0],[0,0,false,0],[0,0,false,0]];

}
Player.prototype.draw= function(){
  ctx.translate(this.x,this.y);
  ctx.rotate(this.rotate*Math.PI/180);
  ctx.translate(-50,-37);
  ctx.drawImage(this.img,0,0);
  ctx.translate(-50,-37);
  ctx.rotate(-(this.rotate*Math.PI/180));
  ctx.translate(this.x,this.y);
  ctx.setTransform(1, 0, 0, 1, 0, 0);
 }

Player.prototype.update=function(){
    for(var i=0;i<5;i++){
      if(this.bullets[i][2]==false){
        this.bullets[i][0]=this.x
        this.bullets[i][1]=this.y
        this.bullets[i][3]=this.rotate
      }else{
        this.bullets[i][0]=10*(Math.sin(this.bullets[i][3]*Math.PI/180));
        this.bullets[i][1]=10*(Math.cos(this.bullets[i][3]*Math.PI/180))
      }
    }


  if (this.y<45){
    this.y=46;
  }
  if(this.y>720-45){
    this.y=720-46;
  }
  if(this.x<45){
    this.x=46;
  }
  if(this.x>1280-45){
    this.x=1280-46;
  }
  if(this.rotating==true){
    if(this.rotating_direction==true){
      this.rotate-=1.8;
    }else {
      this.rotate+=1.8;
    }
  };

  if(this.speed>this.max_speed){
    this.speed=this.max_speed;
  }
  if(this.speed<0){
    this.speed=0;
  }
  if(this.speed>0){
    this.x+=this.speed*(Math.sin(this.rotate*Math.PI/180));
    this.y-=this.speed*(Math.cos(this.rotate*Math.PI/180))
  }
}
module.exports = {
  Player : Player


}
