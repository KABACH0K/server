var  express = require('express');
var http = require('http');
var app = express();
var server = http.createServer(app);
var io = require('socket.io').listen(server);
server.listen(80);
const player = require(__dirname+'/player.js');
//const bootstrap = require('bootstrap');
var game = require('./game.js');
app.use(express.static(__dirname + '/public'));
//~~~~~~~~~~~~~~~~~~~~
const fs = require('fs');
const jquery = require('jquery');
//~~~~~~~~~~~~~~~~~~~~

var id = 0;

//~~~~~~~~~~~~~~

app.get('/',function(req,res){
res.sendFile(__dirname+'/index.shtml');

});
io.on('connection', function(socket){
  if(id==4){

  }else{
    game.newPlayer(id);
    socket.emit('id',{'id':id});
    setInterval(function(){
    socket.emit('id',{'players':game.Players});
     },10);

    id++
    socket.on('direction', function(data){

            if(data.dir=='left-down'){
              game.Players[data.id].rotating=true;
              game.Players[data.id].rotating_direction=true;
            }else if(data.dir=='right-down'){
              game.Players[data.id].rotating=true;
              game.Players[data.id].rotating_direction=false;

            }else if(data.dir=='up'){
              game.Players[data.id].speed+=1;
            }else if(data.dir=='down'){
              game.Players[data.id].speed-=1;
            }else if(data.dir=='left-up'){
              game.Players[data.id].rotating=false;
            }else if(data.dir=='right-up'){
              game.Players[data.id].rotating=false;
            }


    });
    socket.on('disconnect', function(){

    });
  }

});
