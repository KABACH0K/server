const player = require('./player.js');
var  Players=[null,null,null,null];


var newPlayer = function(id){
  let test0 = new player.Player(id,100,100,0);
  let test1 = new player.Player(id,1000,100,0);
  let test2 = new player.Player(id,1000,500,0);
  let test3 = new player.Player(id,100,500,0);
  if(id==0){
    Players[id]= test0;
  }else if (id==1) {
    Players[id]= test1;
  }else if (id==2) {
    Players[id]= test2;
  }else if (id==3) {
    Players[id]= test3;
  }

}
function collision(){

  for(var i=0;i<4;i++){
    if(Players[i]!==null){
      for(var j =i+1;j<4;j++){

          if(Players[j]!==null){
            var dx = Players[i].x-Players[j].x;
            var dy = Players[i].y-Players[j].y;
            var s = Math.sqrt( dy*dy + dx*dx );
            if(s<90){
        			Players[i].x-=Players[i].speed*(Math.sin(Players[i].rotate*Math.PI/180));
        			Players[i].y+=Players[i].speed*(Math.cos(Players[i].rotate*Math.PI/180));
        			Players[j].x-=Players[j].speed*(Math.sin(Players[j].rotate*Math.PI/180));
        			Players[j].y+=Players[j].speed*(Math.cos(Players[j].rotate*Math.PI/180));
          }
      		}
        }
    }
  }
}
/*
Надо сделать коллизию с перебором примерно так

function collision_players() {
		var dx = player1.x-player2.x;
		var dy = player1.y-player2.y;
		var s = Math.sqrt( dy*dy + dx*dx );
		if(s<90){
			player1.x-=player1.speed*(Math.sin(player1.rotate*Math.PI/180));
			player1.y+=player1.speed*(Math.cos(player1.rotate*Math.PI/180));
			player2.x-=player2.speed*(Math.sin(player2.rotate*Math.PI/180));
			player2.y+=player2.speed*(Math.cos(player2.rotate*Math.PI/180));
		}

}
*/

function loop(){
  collision();
  for(var i=0;i<Players.length;i++){
    if(Players[i]!==null){

          Players[i].update();
    }


  }

  // for(var i=0;i<Players.length;i++){
  //  Players[i].socket.emit('id',Players);
  // }

}
setInterval(function () {
loop();
},10);
module.exports = {
  Players : Players,
  newPlayer : newPlayer

}
