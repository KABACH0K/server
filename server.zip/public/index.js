var Players=[];
$(document).ready(function(){

var canvas =  document.getElementById('canvas');

var ctx = canvas.getContext('2d');
function loadImage(name) {
  var img = new Image();
  img.src = name;
  return img;
}
var img = loadImage('p1.png');
var bg = loadImage('star.png');

function loop(){
  if(Players!==undefined){
    ctx.drawImage(bg,0,0,1280,720);
    for(var i=0;i<Players.length;i++){
      if(Players[i]!=null){
        Players[i].img=img;
        ctx.translate(Players[i].x,Players[i].y);
      ctx.rotate(Players[i].rotate*Math.PI/180);
         ctx.translate(-50,-37);
        ctx.drawImage(Players[i].img,0,0);
        ctx.translate(-50,-37);
        ctx.rotate(-(Players[i].rotate*Math.PI/180));
      ctx.translate(Players[i].x,Players[i].y) ;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      }
      console.log(Players);


  }
}
}

setInterval(
  function(){
    loop()},10
 );



});
