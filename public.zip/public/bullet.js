var Bullet = function(x,y,rotate){
  this.x=x;
  this.rotate=rotate;
}
