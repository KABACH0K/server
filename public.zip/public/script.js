canvas = document.getElementById('canvas');

ctx = canvas.getContext("2d");

$(document).ready(function(){



	function loadImage(name) {
		var img = new Image();
		img.src = name;
		return img;
	}

   var star = loadImage('bg.jpg')
	 var p1_image= loadImage('p1.png');
	 var p2_image= loadImage('p2.png');
	 var player1= new Player("Первый игрок",1,200,100,0,p1_image);
	 var player2= new Player("оВторй игрок",2,100,200,90,p2_image);

function collision_players() {
		var dx = player1.x-player2.x;
		var dy = player1.y-player2.y;
		var s = Math.sqrt( dy*dy + dx*dx );
		if(s<90){
			player1.x-=player1.speed*(Math.sin(player1.rotate*Math.PI/180));
			player1.y+=player1.speed*(Math.cos(player1.rotate*Math.PI/180));
			player2.x-=player2.speed*(Math.sin(player2.rotate*Math.PI/180));
			player2.y+=player2.speed*(Math.cos(player2.rotate*Math.PI/180));
		}

}

	function loop() {
		ctx.drawImage(star,0,0);
		player1.update();
		player2.update();
		collision_players();
		player1.draw();
		player2.draw();
		//console.log("tic");


	}

	setInterval(function(){
		loop()
	}
	,10);
  $(document).keydown(function(e){

		if(e.keyCode==37){
		      player1.rotating=true;
					player1.rotating_direction=true;
		 }
		 if(e.keyCode==39){
 		      player1.rotating=true;
					player1.rotating_direction=false;
 		 }
		 if(e.keyCode==38){
			player1.speed+=1;
		 }
		 if(e.keyCode==40){
			 player1.speed-=1;
		 }

//~~~~~~~~~~~~~~~~~~~~~~~~~~
		 if(e.keyCode==65){
 		      player2.rotating=true;
 					player2.rotating_direction=true;
 		 }
 		 if(e.keyCode==68){
  		      player2.rotating=true;
 					player2.rotating_direction=false;
  		 }
 		 if(e.keyCode==87){
 			player2.speed+=1;
 		 }
 		 if(e.keyCode==83){
 			 player2.speed-=1;
 		 }


	})
  $(document).keyup(function(e){
		if(e.keyCode==39){
					player1.rotating=false;
		 }
		 if(e.keyCode==37){
 		      player1.rotating=false;

 		 }
		 if(e.keyCode==65){
 					player2.rotating=false;
 		 }
 		 if(e.keyCode==68){
  		      player2.rotating=false;

  		 }
		if(e.keyCode==88){
			bullets[bullet_index]= new Bullet(player2.x,player2.y,player2.rotate);
		}
		if(e.keyCode==32){
			bullets[bullet_index]= new Bullet(player1.x,player1.y,player1.rotate);
		}


	})



});
