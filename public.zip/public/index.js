// $(document).ready(function(){
//
//
//   $(document).keydown(function(e){
//
// 		if(e.keyCode==37){
// 		      player1.rotating=true;
// 					player1.rotating_direction=true;
// 		 }
// 		 if(e.keyCode==39){
//  		      player1.rotating=true;
// 					player1.rotating_direction=false;
//  		 }
// 		 if(e.keyCode==38){
// 			player1.speed+=1;
// 		 }
// 		 if(e.keyCode==40){
// 			 player1.speed-=1;
// 		 }
// });
//
//
//   $(document).keyup(function(e){
// 		if(e.keyCode==39){
// 					player1.rotating=false;
// 		 }
// 		 if(e.keyCode==37){
//  		      player1.rotating=false;
//
//  		 }
//
//
// 	});
//
//
//
//
// });
